from flask import Flask, request, make_response, redirect, url_for, session, render_template

app = Flask("Sedma vježba")

app.secret_key = '_5#y2L"F4Q8z-n-xec]/'

@app.before_request
def before_request_func():
    if request.path == '/login' or request.path.startswith('/static'):
        return

    if session.get('username') is None:
        return redirect(url_for('login_page'))

@app.get('/')
def home_page():
    response = make_response(render_template('index.html'), 200)
    return response

@app.get('/login')
def login_page():
    response = make_response(render_template('login.html'), 200)
    return response

@app.post('/login')
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    if username == 'PURS' and password == '1234':
        session['username'] = username
        return redirect(url_for('home_page'))
    else:
        return redirect(url_for('login_page'))

@app.get('/logout')
def logout():
    session.pop('username')
    return redirect(url_for('login_page'))

@app.post('/temperatura')
def set_temperature():
    response = make_response()

    if request.json.get('temperatura') is not None:
        response.data = 'Uspješno ste postavili temperaturu'
        response.status_code = 201
    else:
        response.data = 'Niste napisali ispravan ključ'
        response.status_code = 404
    return response

@app.get('/temperatura')
def get_temepratura():
    json = { 
        'temperatura': 15 
    }
    response = make_response(json, 200)
    return response

@app.delete('/temperatura')
def delete_temperature():
    response = make_response()

    if request.args.get('id') is not None:
        response.data = 'Uspješno ste obrisali temepraturu'
        response.status_code = 202
    else:
        response.data = 'Upisali ste neispravan ključ'
        response.status_code = 404
    return response

if __name__=='__main__':
    app.run(host="0.0.0.0", port=80)